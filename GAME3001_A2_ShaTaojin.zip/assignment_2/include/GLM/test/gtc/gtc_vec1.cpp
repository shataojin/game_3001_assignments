#include <glm/gtc/vec1.hpp>

int main()
{
	int Error = 0;

	return Error;
}
